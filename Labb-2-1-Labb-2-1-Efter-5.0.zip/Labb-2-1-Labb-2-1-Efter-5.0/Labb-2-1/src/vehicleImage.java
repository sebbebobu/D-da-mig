
import java.awt.*;
import java.awt.image.BufferedImage;

public class vehicleImage {
    public BufferedImage Image;
    public Point Point;

    public vehicleImage(BufferedImage vehicleImage, Point vehiclePoint){
        this.Image = vehicleImage;
        this.Point = vehiclePoint;
    }

}
