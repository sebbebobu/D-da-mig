
import java.awt.*;
import java.awt.image.BufferedImage;

public class VehicleImage {
    public BufferedImage Image;
    public Point point;

    public VehicleImage(BufferedImage vehicleImage, Point vehiclePoint){
        this.Image = vehicleImage;
        this.point = vehiclePoint;
    }

}
